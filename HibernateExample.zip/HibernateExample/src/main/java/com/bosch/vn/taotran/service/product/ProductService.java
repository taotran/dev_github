package com.bosch.vn.taotran.service.product;

import com.bosch.vn.taotran.model.category.Category;
import com.bosch.vn.taotran.model.product.Product;
import com.bosch.vn.taotran.service.EntityService;

import java.util.List;

/**
 * Created by TRA3HC on 8/25/2016.
 */
public interface ProductService extends EntityService<Product> {

    List<Product> findByCategory(Category category);

    List<Product> findByCategory(long categoryId);
}


