package com.bosch.vn.taotran.service;

import com.bosch.vn.taotran.model.AbstractEntity;
import com.bosch.vn.taotran.model.IdentifiableEntity;

import java.util.List;

/**
 * Created by TRA3HC on 8/25/2016.
 */
public interface EntityService<T extends AbstractEntity> {

    List<T> findAll();

    T save(T t);

    T findOne(long id);

}
