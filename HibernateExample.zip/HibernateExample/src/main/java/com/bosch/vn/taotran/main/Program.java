package com.bosch.vn.taotran.main;

import com.bosch.vn.taotran.config.MyApplicationContext;
import com.bosch.vn.taotran.model.category.Category;
import com.bosch.vn.taotran.model.product.Product;
import com.bosch.vn.taotran.service.category.CategoryService;
import com.bosch.vn.taotran.service.product.ProductService;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Created by TRA3HC on 8/22/2016.
 */
@Component
public class Program {

    private static SessionFactory sessionFactory;


    @Autowired
    TestService testService;

    @Autowired
    ProductService productService;

    @Autowired
    CategoryService categoryService;


    public static void main(String[] args) {

//        sessionFactory = new AnnotationConfiguration().configure().addPackage("com.bosch.vn.taotran.model.*").buildSessionFactory();
//        sessionFactory = new AnnotationConfiguration().configure().
//                buildSessionFactory();
//
//        findAll();
//
        ApplicationContext context = new AnnotationConfigApplicationContext(MyApplicationContext.class);
        Program programBean = context.getBean(Program.class);

        programBean.testService.printText();
        System.out.println(programBean.productService.findAll().size());
        System.out.println("#####");
        List<Category> categories = programBean.categoryService.findAll();

        for (Category category: categories) {
            List<Product> products = programBean.productService.findByCategory(category);
            System.out.println(products.size());
        }

        System.out.println("done");

        //programBean.create10Category();
        programBean.create10000000Product();

    }


    public void create10Category() {
        for (int i=2; i<=12; i++) {
            Category category = new Category();
            category.setName("Category" + i);
            category.setCreatedDate(new Date());

            Category c = this.categoryService.save(category);

            System.out.println(c.getId());
        }
    }

    public void create10000000Product() {
        for (int i=119500; i<=10000000; i++) {
            Product product = new Product();
            product.setName("This is product " + i);
            product.setCode("prod" + i);
            product.setCreatedDate(new Date());
            product.setPrice(new Double(ThreadLocalRandom.current().nextInt(1, 100)));
            Integer random = ThreadLocalRandom.current().nextInt(1, 13);
            Category category = categoryService.findOne(new Long(random));

            product.setCategory(category);

            Product prod = productService.save(product);

            System.out.println(prod.getId());
        }
    }

//    public static List<Product> findAll() {
//        Session session = sessionFactory.openSession();
//        Transaction transaction = null;
//
//        transaction = session.beginTransaction();
//
//        @SuppressWarnings("unchecked")
//        List<Product> products = session.createQuery("FROM Product").list();
//        transaction.commit();
//        return products;
//    }
}
