package com.bosch.vn.taotran.repository.product;

import com.bosch.vn.taotran.model.category.Category;
import com.bosch.vn.taotran.model.product.Product;
import com.bosch.vn.taotran.repository.EntityRepository;
import org.springframework.cache.annotation.Cacheable;

import java.util.List;

/**
 * Created by TRA3HC on 8/23/2016.
 */
public interface ProductRepository extends EntityRepository<Product> {

    List<Product> findByCategory(Category category);

    @Cacheable(cacheNames = "cache_product")
    List<Product> findAll();
}
