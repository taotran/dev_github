package com.bosch.vn.taotran.model.product;

import com.bosch.vn.taotran.model.AbstractEntity;
import com.bosch.vn.taotran.model.category.Category;
import org.hibernate.annotations.*;
import org.hibernate.annotations.Cache;

import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Created by TRA3HC on 8/19/2016.
 */
@Entity
//@Cacheable
//@Cache(usage = CacheConcurrencyStrategy.READ_ONLY, region = "cache_product")
@Table(name = "product")
public class Product extends AbstractEntity {

    @Column(name = "code", nullable = false, insertable = true)
    private String code;
    @Column(name = "name", nullable = false)
    private String name;
    @Column(name = "price", nullable = false, precision = 0)
    private double price;



    @ManyToOne
    @JoinColumn(name = "fk_category")
    private Category category;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        Product product = (Product) o;

        return new org.apache.commons.lang3.builder.EqualsBuilder()
                .append(code, product.code)
                .append(name, product.name)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new org.apache.commons.lang3.builder.HashCodeBuilder(17, 37)
                .append(code)
                .append(name)
                .toHashCode();
    }
}
