package com.bosch.vn.taotran.model.category;

import com.bosch.vn.taotran.model.AbstractEntity;
import com.bosch.vn.taotran.model.product.Product;

import javax.persistence.*;
import java.util.*;

/**
 * Created by TRA3HC on 8/25/2016.
 */
@Entity
@Table(name = "category")
public class Category extends AbstractEntity {


    @Column(name = "name")
    private String name;

    @OneToMany(mappedBy = "category", targetEntity = Product.class, cascade = CascadeType.ALL)
    private Set<Product> products = new HashSet<Product>();


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Product> getProducts() {
        return products;
    }

    public void setProducts(Set<Product> products) {
        this.products = products;
    }
}
