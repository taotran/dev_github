package com.bosch.vn.taotran.config;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.*;

/**
 * Created by TRA3HC on 8/22/2016.
 */
@Configuration
@Import(value = {PersistenceConfig.class, CacheConfig.class})
@ComponentScan(basePackages = {"com.bosch.vn.taotran"})
@PropertySource(value = "classpath:hibernate.properties")
public class MyApplicationContext {

    @Bean
    @Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
    public String myTestBean() {
       return new String("### inside myTestBean ####");
    }
}
