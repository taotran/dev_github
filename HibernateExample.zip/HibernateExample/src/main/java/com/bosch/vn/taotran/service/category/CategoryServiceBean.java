package com.bosch.vn.taotran.service.category;

import com.bosch.vn.taotran.model.category.Category;
import com.bosch.vn.taotran.service.EntityServiceBean;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by TRA3HC on 8/26/2016.
 */
@Service
@Transactional
public class CategoryServiceBean extends EntityServiceBean<Category> implements CategoryService {



}
