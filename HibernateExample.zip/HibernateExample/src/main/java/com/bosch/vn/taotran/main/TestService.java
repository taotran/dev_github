package com.bosch.vn.taotran.main;

import org.springframework.stereotype.Service;

/**
 * Created by TRA3HC on 8/25/2016.
 */
@Service
public class TestService {

    public void printText() {
        System.out.println("this is sample text");
    }
}
