package com.bosch.vn.taotran.repository;

import com.bosch.vn.taotran.model.AbstractEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

/**
 * Created by TRA3HC on 8/26/2016.
 */
@NoRepositoryBean
public interface EntityRepository<T extends AbstractEntity> extends JpaRepository<T, Long> {

}
