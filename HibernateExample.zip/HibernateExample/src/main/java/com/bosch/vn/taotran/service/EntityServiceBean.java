package com.bosch.vn.taotran.service;

import com.bosch.vn.taotran.model.AbstractEntity;
import com.bosch.vn.taotran.repository.EntityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

/**
 * Created by TRA3HC on 8/26/2016.
 */
@Transactional
public class EntityServiceBean<T extends AbstractEntity> implements EntityService<T> {

    @PersistenceContext
    EntityManager em;

    @Autowired
    private EntityRepository<T> repository;

    public List<T> findAll() {
        return repository.findAll();
    }

    public T findOne(long id) {
        return repository.findOne(id);
    }

    public List<T> findAll(int start, int end) {
        return repository.findAll(new PageRequest(1, 10)).getContent();
    }

    @Transactional
    public T save(T entity) {
        em.persist(entity);
        em.flush();
        return entity;
    }

    public void delete(T t) {
        repository.delete(t);
    }


}
