package com.bosch.vn.taotran.model;

import java.io.Serializable;

/**
 * Created by TRA3HC on 8/19/2016.
 */
public interface IdentifiableEntity extends Serializable{

   Long getId();
}
