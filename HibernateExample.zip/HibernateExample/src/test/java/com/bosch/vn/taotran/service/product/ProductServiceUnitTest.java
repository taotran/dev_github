package com.bosch.vn.taotran.service.product;

import com.bosch.vn.taotran.config.MyApplicationContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

/**
 * Created by TRA3HC on 8/26/2016.
 */

@Test
@Component
public class ProductServiceUnitTest {

    @Autowired
    private ProductService productService;

    @BeforeTest
    public void initTest() {
        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(MyApplicationContext.class);
    }

    public void testCache() {

        productService.findAll();
        productService.findAll();
        productService.findAll();
    }
}
