package com.bosch.vn.taotran.service.category;

import com.bosch.vn.taotran.model.category.Category;
import com.bosch.vn.taotran.service.EntityService;

/**
 * Created by TRA3HC on 8/26/2016.
 */
public interface CategoryService extends EntityService<Category> {
}
