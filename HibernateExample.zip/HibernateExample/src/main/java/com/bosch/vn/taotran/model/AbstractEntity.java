package com.bosch.vn.taotran.model;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by TRA3HC on 8/19/2016.
 */
@MappedSuperclass
public class AbstractEntity implements IdentifiableEntity {

    @Id
    @Column(name = "id", nullable = false, insertable = false, unique = true)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "createdDate")
    private Date createdDate;

    @Column(name = "updateDate")
    private Date updateDate;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
}
