package com.bosch.vn.taotran.repository.category;

import com.bosch.vn.taotran.model.category.Category;
import com.bosch.vn.taotran.repository.EntityRepository;

/**
 * Created by TRA3HC on 8/26/2016.
 */
public interface CategoryRepository extends EntityRepository<Category> {
}
