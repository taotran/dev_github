package com.bosch.vn.taotran.service.product;

import com.bosch.vn.taotran.model.category.Category;
import com.bosch.vn.taotran.model.product.Product;
import com.bosch.vn.taotran.repository.product.ProductRepository;
import com.bosch.vn.taotran.service.EntityServiceBean;
import com.bosch.vn.taotran.service.category.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by TRA3HC on 8/25/2016.
 */
@Service
public class ProductServiceBean extends EntityServiceBean<Product> implements ProductService {

    @Autowired
    ProductRepository productRepository;

    @Autowired
    CategoryService categoryService;

    @Override
    @Transactional
    public Product save(Product entity) {
        return super.save(entity);
    }

    @Override
    @Transactional
    public void delete(Product product) {
        super.delete(product);
    }

    public List<Product> findByCategory(Category category) {
        return productRepository.findByCategory(category);
    }

    public List<Product> findByCategory(long categoryId) {
        return this.findByCategory(categoryService.findOne(categoryId));
    }
}
