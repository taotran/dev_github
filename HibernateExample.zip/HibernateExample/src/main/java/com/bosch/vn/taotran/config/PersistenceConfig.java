package com.bosch.vn.taotran.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaDialect;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaDialect;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.persistence.EntityManager;
import javax.sql.DataSource;
import java.util.Properties;


/**
 * Created by TRA3HC on 8/22/2016.
 */
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = {"com.bosch.vn.taotran.repository"})
public class PersistenceConfig {


    private static final String PROPERTY_DATABASE_DRIVER = "hibernate.jdbc.driver_class";
    private static final String PROPERTY_DATABASE_URL = "hibernate.connection.url";
    private static final String PROPERTY_DATABASE_USERNAME = "hibernate.connection.username";
    private static final String PROPERTY_DATABASE_PW = "hibernate.connection.password";
    private static final String PROPERTY_HIBERNATE_DIALECT = "hibernate.dialect";
    private static final String PROPERTY_SHOW_SQL = "hibernate.show_sql";

    private static final String PACKAGES_TO_SCAN = "com.bosch.vn.taotran.model";

    @Autowired
    private Environment environment;

    @Bean
    public DataSource dataSource() {
        final DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(environment.getProperty(PROPERTY_DATABASE_DRIVER));
        dataSource.setUsername(environment.getProperty(PROPERTY_DATABASE_USERNAME));
        dataSource.setPassword(environment.getProperty(PROPERTY_DATABASE_PW));
        dataSource.setUrl(environment.getProperty(PROPERTY_DATABASE_URL));
        return dataSource;
    }

    @Bean
    public EntityManager entityManager() {
        return entityManagerFactoryBean().getObject().createEntityManager();
    }

    @Bean(name = "entityManagerFactory")
    public LocalContainerEntityManagerFactoryBean entityManagerFactoryBean() {
        final HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        vendorAdapter.setShowSql(true);
        vendorAdapter.setGenerateDdl(true);
        final LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setPackagesToScan(PACKAGES_TO_SCAN);
        em.setDataSource(dataSource());
        em.setJpaDialect(jpaDialect());
        em.setJpaProperties(jpaProperties());
        em.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
        return em;
    }

    @Bean
    public JpaDialect jpaDialect() {
        return new HibernateJpaDialect();
    }

    @Bean
    public PlatformTransactionManager transactionManager() {
        JpaTransactionManager tm = new JpaTransactionManager();
        tm.setEntityManagerFactory(entityManagerFactoryBean().getObject());
        tm.setDataSource(dataSource());
        return tm;
    }

    private Properties jpaProperties() {
        final Properties p = new Properties();
        p.setProperty("hibernate.dialect", environment.getProperty(PROPERTY_HIBERNATE_DIALECT));
        p.setProperty("hibernate.hbm2ddl.auto", environment.getProperty("hibernate.hbm2ddl.auto"));
        p.setProperty("hibernate.show_sql", environment.getProperty(PROPERTY_SHOW_SQL));

        return p;
    }



}
